# Przewodnik: Ćwiczenia Jobów Jenkins z Pytest

Ten dokument opisuje, jak skonfigurować zadania (joby) w Jenkinsie do uruchamiania testów `pytest` dla wcześniej przygotowanych ćwiczeń. Zakładamy, że agent Jenkinsa jest już poprawnie skonfigurowany i połączony z serwerem master.

## Wymagania Wstępne

- **Działający agent Jenkins:** Agent na Ubuntu z etykietą (np. `ubuntu`) jest dostępny i online.
- **Zainstalowane narzędzia na agencie:** Na agencie muszą być dostępne `git`, `python3` oraz `python3-venv`. Można je zainstalować poleceniem:
  ```bash
  sudo apt update && sudo apt install -y git python3-pip python3-venv
  ```
- **Kod źródłowy:** Przykładowe projekty z testami powinny być dostępne w repozytorium Git. Na potrzeby tego ćwiczenia, założymy, że kod jest dostępny w publicznym repozytorium na GitHub (w rzeczywistości kod znajduje się lokalnie, ale w instrukcjach użyjemy Git do symulacji realnego przepływu pracy).

## Przygotowanie Repozytorium Git

Przed kontynuowaniem, należy umieścić wcześniej przygotowane projekty w repozytorium Git. Struktura repozytorium powinna wyglądać następująco:

```
/ (root repozytorium)
├── exercise1-basic/
│   ├── calculator.py
│   ├── test_calculator.py
│   ├── requirements.txt
│   └── README.md
├── exercise2-api/
│   └── ...
└── exercise3-parametrized/
    └── ...
```

**Ważne:** W poniższych instrukcjach należy zastąpić `https://github.com/twoje-konto/twoje-repo.git` adresem URL do rzeczywistego repozytorium.

---



## Ćwiczenie 1: Podstawowe Testy Jednostkowe (Freestyle Project)

To zadanie skonfiguruje job typu Freestyle do uruchamiania podstawowych testów jednostkowych dla kalkulatora.

1.  **Stwórz nowy job:**
    - W panelu Jenkinsa przejdź do `Dashboard` > `New Item`.
    - Wprowadź nazwę, np. `Pytest-Exercise-1-Basic-Freestyle`.
    - Wybierz `Freestyle project` i kliknij `OK`.

2.  **Skonfiguruj job:**
    - **General:**
        - (Opcjonalnie) Wpisz opis zadania.
    - **Restrict where this project can be run:**
        - Zaznacz tę opcję i wpisz etykietę swojego agenta, np. `ubuntu`.
    - **Source Code Management:**
        - Wybierz `Git`.
        - **Repository URL:** Wprowadź URL do swojego repozytorium Git.
        - **Branch Specifier:** Pozostaw `*/main` lub zmień na odpowiednią gałąź.
    - **Build Steps:**
        - Kliknij `Add build step` i wybierz `Execute shell`.
        - W polu `Command` wklej poniższy skrypt. Skrypt ten tworzy wirtualne środowisko, instaluje zależności, uruchamia testy i generuje raporty.

          ```bash
          #!/bin/bash
          set -e  # Przerwij w przypadku błędu

          echo "================================================="
          echo " PRZYGOTOWANIE ŚRODOWISKA PYTEST           "
          echo "================================================="

          # Użyj katalogu z ćwiczeniem 1
          cd exercise1-basic

          # Sprawdź wersję Pythona
          python3 --version

          # Utwórz i aktywuj wirtualne środowisko
          python3 -m venv venv
          source venv/bin/activate

          # Zainstaluj zależności
          pip install -r requirements.txt

          echo "================================================="
          echo " URUCHAMIANIE TESTÓW PYTEST                 "
          echo "================================================="

          # Uruchom testy z generowaniem raportu HTML i pokrycia kodu
          pytest --junitxml=reports/junit.xml --html=reports/report.html --self-contained-html --cov=calculator --cov-report=xml

          echo "================================================="
          echo " ZAKOŃCZONO TESTY                            "
          echo "================================================="
          ```

    - **Post-build Actions:**
        - **Publish JUnit test result report:**
            - `Test report XMLs`: `exercise1-basic/reports/junit.xml`
        - **Publish HTML reports:**
            - `HTML directory to archive`: `exercise1-basic/reports`
            - `Index page[s]`: `report.html`
            - `Report title`: `Pytest Report`
        - **Publish Cobertura Coverage Report:**
            - `Cobertura XML report pattern`: `exercise1-basic/coverage.xml`

3.  **Zapisz i uruchom:**
    - Kliknij `Save`, a następnie `Build Now`. Po zakończeniu budowania, na stronie joba pojawią się linki do raportu z testów, raportu HTML oraz raportu pokrycia kodu.

---

## Ćwiczenie 2: Testy API z użyciem Pipeline (Jenkinsfile)

To zadanie wykorzystuje Jenkins Pipeline (z plikiem `Jenkinsfile`) do uruchamiania testów API. Pipeline pozwala na definiowanie procesu budowania jako kodu, co jest bardziej elastyczne i przenośne.

1.  **Stwórz plik `Jenkinsfile` w repozytorium:**
    W głównym katalogu swojego repozytorium Git utwórz plik o nazwie `Jenkinsfile` z poniższą zawartością.

    ```groovy
    pipeline {
        agent { label 'ubuntu' } // Uruchom na agencie z etykietą 'ubuntu'

        stages {
            stage('Setup Environment') {
                steps {
                    script {
                        dir('exercise2-api') { // Przejdź do katalogu z ćwiczeniem
                            echo '--- Preparing Python Environment ---'
                            sh 'python3 -m venv venv'
                            sh 'source venv/bin/activate && pip install -r requirements.txt'
                        }
                    }
                }
            }
            stage('Run Pytest') {
                steps {
                    script {
                        dir('exercise2-api') { // Przejdź do katalogu z ćwiczeniem
                            echo '--- Running Pytest ---'
                            sh 'source venv/bin/activate && pytest --junitxml=reports/junit.xml --html=reports/report.html --self-contained-html --cov=api_client --cov-report=xml'
                        }
                    }
                }
            }
        }

        post {
            always {
                echo '--- Archiving Reports ---'
                junit 'exercise2-api/reports/junit.xml'
                publishHTML(
                    target: [
                        reportDir: 'exercise2-api/reports',
                        reportFiles: 'report.html',
                        reportName: 'Pytest HTML Report'
                    ]
                )
                cobertura(
                    coberturaReportFile: 'exercise2-api/coverage.xml'
                )
            }
        }
    }
    ```

2.  **Stwórz nowy job:**
    - W panelu Jenkinsa przejdź do `Dashboard` > `New Item`.
    - Wprowadź nazwę, np. `Pytest-Exercise-2-API-Pipeline`.
    - Wybierz `Pipeline` i kliknij `OK`.

3.  **Skonfiguruj job:**
    - **General:**
        - (Opcjonalnie) Wpisz opis zadania.
    - **Pipeline:**
        - **Definition:** Wybierz `Pipeline script from SCM`.
        - **SCM:** Wybierz `Git`.
        - **Repository URL:** Wprowadź URL do swojego repozytorium Git.
        - **Branch Specifier:** Pozostaw `*/main`.
        - **Script Path:** Domyślnie jest to `Jenkinsfile`, co jest poprawne.

4.  **Zapisz i uruchom:**
    - Kliknij `Save`, a następnie `Build Now`. Jenkins automatycznie pobierze kod, odczyta plik `Jenkinsfile` i wykona zdefiniowane w nim etapy.

---

## Ćwiczenie 3: Testy Parametryzowane (Pipeline z parametrami)

To zadanie rozszerza koncepcję Pipeline, dodając parametry, które można przekazywać do budowania. Pozwoli to na dynamiczne kontrolowanie zachowania testów.

1.  **Zaktualizuj `Jenkinsfile`:**
    Zmodyfikuj plik `Jenkinsfile`, aby akceptował parametry. W tym przykładzie dodamy parametr `PYTEST_ARGS`, który pozwoli na przekazywanie dodatkowych argumentów do `pytest`.

    ```groovy
    pipeline {
        agent { label 'ubuntu' }

        parameters {
            string(name: 'PYTEST_ARGS', defaultValue: '-v --tb=short', description: 'Dodatkowe argumenty dla pytest')
        }

        stages {
            stage('Setup Environment') {
                steps {
                    script {
                        dir('exercise3-parametrized') {
                            echo '--- Preparing Python Environment ---'
                            sh 'python3 -m venv venv'
                            sh 'source venv/bin/activate && pip install -r requirements.txt'
                        }
                    }
                }
            }
            stage('Run Pytest') {
                steps {
                    script {
                        dir('exercise3-parametrized') {
                            echo "--- Running Pytest with args: ${params.PYTEST_ARGS} --- "
                            sh "source venv/bin/activate && pytest ${params.PYTEST_ARGS} --junitxml=reports/junit.xml --html=reports/report.html --self-contained-html"
                        }
                    }
                }
            }
        }

        post {
            always {
                echo '--- Archiving Reports ---'
                junit 'exercise3-parametrized/reports/junit.xml'
                publishHTML(
                    target: [
                        reportDir: 'exercise3-parametrized/reports',
                        reportFiles: 'report.html',
                        reportName: 'Pytest HTML Report'
                    ]
                )
            }
        }
    }
    ```

2.  **Stwórz nowy job (lub zmodyfikuj istniejący):**
    - Możesz stworzyć nowy job typu Pipeline, analogicznie do ćwiczenia 2, lub zmodyfikować istniejący, aby korzystał z nowego `Jenkinsfile`.
    - Nazwij go np. `Pytest-Exercise-3-Parametrized-Pipeline`.

3.  **Uruchom z parametrami:**
    - Po zapisaniu joba, zamiast `Build Now` pojawi się opcja `Build with Parameters`.
    - Kliknij ją, a zobaczysz pole `PYTEST_ARGS` z domyślną wartością.
    - Możesz uruchomić budowanie z domyślnymi argumentami lub je zmienić, np. dodając `-k "palindrome"`, aby uruchomić tylko testy zawierające w nazwie słowo `palindrome`.

## Podsumowanie

Te trzy ćwiczenia pokazują ewolucję od prostego joba Freestyle do elastycznych i potężnych Pipeline'ów. Użycie `Jenkinsfile` jest obecnie standardem w nowoczesnych wdrożeniach CI/CD, ponieważ pozwala na wersjonowanie i przeglądanie kodu definiującego proces budowania razem z kodem aplikacji.

