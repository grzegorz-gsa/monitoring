"""
Testy parametryzowane dla modułu string_utils.
Demonstracja użycia @pytest.mark.parametrize do testowania wielu przypadków.
"""
import pytest
from string_utils import (
    is_palindrome,
    count_vowels,
    reverse_words,
    is_valid_email,
    capitalize_words
)


class TestStringUtils:
    """Testy dla funkcji przetwarzania stringów."""

    @pytest.mark.parametrize("text,expected", [
        ("kajak", True),
        ("Kajak", True),
        ("A man a plan a canal Panama", True),
        ("hello", False),
        ("racecar", True),
        ("RaceCar", True),
        ("Was it a car or a cat I saw", True),
        ("python", False),
        ("", True),  # Pusty string jest palindromem
        ("a", True),
    ])
    def test_is_palindrome(self, text, expected):
        """Test sprawdzania palindromów z różnymi przypadkami."""
        assert is_palindrome(text) == expected

    @pytest.mark.parametrize("text,expected", [
        ("hello", 2),
        ("HELLO", 2),
        ("aeiou", 5),
        ("bcdfg", 0),
        ("Python Programming", 4),
        ("", 0),
        ("AEIOUaeiou", 10),
    ])
    def test_count_vowels(self, text, expected):
        """Test zliczania samogłosek."""
        assert count_vowels(text) == expected

    @pytest.mark.parametrize("text,expected", [
        ("hello world", "world hello"),
        ("one two three", "three two one"),
        ("Python", "Python"),
        ("", ""),
        ("a b c d e", "e d c b a"),
    ])
    def test_reverse_words(self, text, expected):
        """Test odwracania kolejności słów."""
        assert reverse_words(text) == expected

    @pytest.mark.parametrize("email,expected", [
        ("user@example.com", True),
        ("test.user@domain.co.uk", True),
        ("invalid.email", False),
        ("@example.com", False),
        ("user@", False),
        ("user@domain", False),
        ("user name@example.com", False),
        ("user+tag@example.com", True),
        ("user_123@test-domain.com", True),
        ("", False),
    ])
    def test_is_valid_email(self, email, expected):
        """Test walidacji adresów email."""
        assert is_valid_email(email) == expected

    @pytest.mark.parametrize("text,expected", [
        ("hello world", "Hello World"),
        ("python programming", "Python Programming"),
        ("UPPERCASE", "Uppercase"),
        ("lowercase", "Lowercase"),
        ("MiXeD CaSe", "Mixed Case"),
        ("", ""),
        ("a", "A"),
    ])
    def test_capitalize_words(self, text, expected):
        """Test kapitalizacji słów."""
        assert capitalize_words(text) == expected


# Testy z wieloma parametrami
@pytest.mark.parametrize("func,input_val,expected", [
    (is_palindrome, "radar", True),
    (count_vowels, "beautiful", 5),
    (reverse_words, "test case", "case test"),
])
def test_multiple_functions(func, input_val, expected):
    """Test wielu funkcji w jednym teście parametryzowanym."""
    assert func(input_val) == expected

