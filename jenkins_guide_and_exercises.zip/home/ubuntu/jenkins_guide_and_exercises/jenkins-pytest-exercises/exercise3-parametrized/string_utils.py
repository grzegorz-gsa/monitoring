"""
Moduł z funkcjami do przetwarzania stringów.
"""
import re


def is_palindrome(text):
    """
    Sprawdza, czy tekst jest palindromem (ignoruje wielkość liter i znaki niealfanumeryczne).
    
    Args:
        text: Tekst do sprawdzenia
        
    Returns:
        bool: True jeśli tekst jest palindromem
    """
    # Usuń znaki niealfanumeryczne i zamień na małe litery
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', text).lower()
    return cleaned == cleaned[::-1]


def count_vowels(text):
    """
    Zlicza samogłoski w tekście.
    
    Args:
        text: Tekst do analizy
        
    Returns:
        int: Liczba samogłosek
    """
    vowels = 'aeiouAEIOU'
    return sum(1 for char in text if char in vowels)


def reverse_words(text):
    """
    Odwraca kolejność słów w tekście.
    
    Args:
        text: Tekst do przetworzenia
        
    Returns:
        str: Tekst z odwróconą kolejnością słów
    """
    return ' '.join(text.split()[::-1])


def is_valid_email(email):
    """
    Sprawdza, czy adres email jest poprawny (prosta walidacja).
    
    Args:
        email: Adres email do sprawdzenia
        
    Returns:
        bool: True jeśli email jest poprawny
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def capitalize_words(text):
    """
    Kapitalizuje pierwsze litery wszystkich słów.
    
    Args:
        text: Tekst do przetworzenia
        
    Returns:
        str: Tekst z kapitalizowanymi słowami
    """
    return ' '.join(word.capitalize() for word in text.split())

