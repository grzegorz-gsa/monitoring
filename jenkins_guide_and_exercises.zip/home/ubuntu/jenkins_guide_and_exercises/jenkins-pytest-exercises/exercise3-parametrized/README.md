# Ćwiczenie 3: Testy Parametryzowane

## Opis

To ćwiczenie demonstruje użycie testów parametryzowanych w pytest. Dekorator `@pytest.mark.parametrize` pozwala na uruchomienie tego samego testu z różnymi zestawami danych wejściowych, co znacznie redukuje duplikację kodu testowego.

## Struktura projektu

- `string_utils.py` - moduł z funkcjami do przetwarzania stringów
- `test_string_utils.py` - testy parametryzowane
- `requirements.txt` - zależności projektu

## Uruchomienie lokalnie

```bash
# Instalacja zależności
pip3 install -r requirements.txt

# Uruchomienie testów
pytest -v

# Uruchomienie testów z szczegółowym wyświetlaniem parametrów
pytest -v --tb=short

# Uruchomienie testów z raportem HTML
pytest --html=report.html --self-contained-html

# Uruchomienie testów z pokryciem kodu
pytest --cov=string_utils --cov-report=html --cov-report=term
```

## Oczekiwany wynik

Wszystkie testy powinny przejść pomyślnie (około 40+ testów z uwagi na parametryzację). Każda kombinacja parametrów jest traktowana jako osobny test.

## Zalety testów parametryzowanych

- Redukcja duplikacji kodu testowego
- Łatwe dodawanie nowych przypadków testowych
- Przejrzysta struktura testów
- Lepsze raportowanie - każdy zestaw parametrów jest widoczny osobno

