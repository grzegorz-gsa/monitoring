"""
Prosty moduł kalkulatora do demonstracji testów jednostkowych.
"""


class Calculator:
    """Klasa implementująca podstawowe operacje matematyczne."""

    def add(self, a, b):
        """Dodaje dwie liczby."""
        return a + b

    def subtract(self, a, b):
        """Odejmuje drugą liczbę od pierwszej."""
        return a - b

    def multiply(self, a, b):
        """Mnoży dwie liczby."""
        return a * b

    def divide(self, a, b):
        """Dzieli pierwszą liczbę przez drugą."""
        if b == 0:
            raise ValueError("Nie można dzielić przez zero")
        return a / b

    def power(self, base, exponent):
        """Podnosi podstawę do potęgi wykładnika."""
        return base ** exponent

