"""
Testy jednostkowe dla modułu calculator.
"""
import pytest
from calculator import Calculator


class TestCalculator:
    """Testy dla klasy Calculator."""

    def setup_method(self):
        """Przygotowanie środowiska testowego przed każdym testem."""
        self.calc = Calculator()

    def test_add_positive_numbers(self):
        """Test dodawania liczb dodatnich."""
        assert self.calc.add(5, 3) == 8
        assert self.calc.add(10, 20) == 30

    def test_add_negative_numbers(self):
        """Test dodawania liczb ujemnych."""
        assert self.calc.add(-5, -3) == -8
        assert self.calc.add(-10, 5) == -5

    def test_subtract(self):
        """Test odejmowania."""
        assert self.calc.subtract(10, 5) == 5
        assert self.calc.subtract(5, 10) == -5

    def test_multiply(self):
        """Test mnożenia."""
        assert self.calc.multiply(4, 5) == 20
        assert self.calc.multiply(-3, 7) == -21

    def test_divide(self):
        """Test dzielenia."""
        assert self.calc.divide(10, 2) == 5
        assert self.calc.divide(9, 3) == 3

    def test_divide_by_zero(self):
        """Test dzielenia przez zero - powinien rzucić wyjątek."""
        with pytest.raises(ValueError, match="Nie można dzielić przez zero"):
            self.calc.divide(10, 0)

    def test_power(self):
        """Test potęgowania."""
        assert self.calc.power(2, 3) == 8
        assert self.calc.power(5, 2) == 25
        assert self.calc.power(10, 0) == 1

