# Ćwiczenie 1: Podstawowe Testy Jednostkowe

## Opis

To ćwiczenie demonstruje podstawowe testy jednostkowe dla prostego kalkulatora. Testy sprawdzają poprawność operacji matematycznych oraz obsługę błędów.

## Struktura projektu

- `calculator.py` - moduł z klasą Calculator
- `test_calculator.py` - testy jednostkowe
- `requirements.txt` - zależności projektu

## Uruchomienie lokalnie

```bash
# Instalacja zależności
pip3 install -r requirements.txt

# Uruchomienie testów
pytest -v

# Uruchomienie testów z raportem HTML
pytest --html=report.html --self-contained-html

# Uruchomienie testów z pokryciem kodu
pytest --cov=calculator --cov-report=html --cov-report=term
```

## Oczekiwany wynik

Wszystkie testy powinny przejść pomyślnie (8 testów).

