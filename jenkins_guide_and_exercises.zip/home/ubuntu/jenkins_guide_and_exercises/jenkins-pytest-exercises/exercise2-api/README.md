# Ćwiczenie 2: Testowanie Klienta API

## Opis

To ćwiczenie demonstruje testowanie klienta API z użyciem biblioteki `responses` do mockowania odpowiedzi HTTP. Testy sprawdzają operacje CRUD (Create, Read, Update, Delete) na zasobach użytkowników.

## Struktura projektu

- `api_client.py` - moduł klienta API
- `test_api_client.py` - testy jednostkowe z mockowaniem HTTP
- `requirements.txt` - zależności projektu

## Uruchomienie lokalnie

```bash
# Instalacja zależności
pip3 install -r requirements.txt

# Uruchomienie testów
pytest -v

# Uruchomienie testów z raportem HTML
pytest --html=report.html --self-contained-html

# Uruchomienie testów z pokryciem kodu
pytest --cov=api_client --cov-report=html --cov-report=term
```

## Oczekiwany wynik

Wszystkie testy powinny przejść pomyślnie (6 testów). Testy używają mockowania, więc nie wymagają rzeczywistego API.

