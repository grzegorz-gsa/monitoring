"""
Moduł klienta API do komunikacji z zewnętrznymi serwisami.
"""
import requests


class APIClient:
    """Klasa do wykonywania zapytań do API."""

    def __init__(self, base_url):
        """
        Inicjalizacja klienta API.
        
        Args:
            base_url: Bazowy URL API
        """
        self.base_url = base_url
        self.session = requests.Session()

    def get_user(self, user_id):
        """
        Pobiera dane użytkownika po ID.
        
        Args:
            user_id: ID użytkownika
            
        Returns:
            dict: Dane użytkownika
        """
        response = self.session.get(f"{self.base_url}/users/{user_id}")
        response.raise_for_status()
        return response.json()

    def create_user(self, user_data):
        """
        Tworzy nowego użytkownika.
        
        Args:
            user_data: Słownik z danymi użytkownika
            
        Returns:
            dict: Utworzony użytkownik
        """
        response = self.session.post(f"{self.base_url}/users", json=user_data)
        response.raise_for_status()
        return response.json()

    def update_user(self, user_id, user_data):
        """
        Aktualizuje dane użytkownika.
        
        Args:
            user_id: ID użytkownika
            user_data: Nowe dane użytkownika
            
        Returns:
            dict: Zaktualizowany użytkownik
        """
        response = self.session.put(f"{self.base_url}/users/{user_id}", json=user_data)
        response.raise_for_status()
        return response.json()

    def delete_user(self, user_id):
        """
        Usuwa użytkownika.
        
        Args:
            user_id: ID użytkownika
            
        Returns:
            bool: True jeśli usunięto pomyślnie
        """
        response = self.session.delete(f"{self.base_url}/users/{user_id}")
        response.raise_for_status()
        return response.status_code == 200

