"""
Testy dla modułu api_client.
Używamy biblioteki responses do mockowania odpowiedzi HTTP.
"""
import pytest
import responses
from api_client import APIClient


class TestAPIClient:
    """Testy dla klasy APIClient."""

    def setup_method(self):
        """Przygotowanie środowiska testowego."""
        self.base_url = "https://api.example.com"
        self.client = APIClient(self.base_url)

    @responses.activate
    def test_get_user_success(self):
        """Test pobierania użytkownika - sukces."""
        user_id = 1
        expected_user = {
            "id": user_id,
            "name": "Jan Kowalski",
            "email": "jan@example.com"
        }
        
        responses.add(
            responses.GET,
            f"{self.base_url}/users/{user_id}",
            json=expected_user,
            status=200
        )
        
        result = self.client.get_user(user_id)
        assert result == expected_user

    @responses.activate
    def test_get_user_not_found(self):
        """Test pobierania nieistniejącego użytkownika."""
        user_id = 999
        
        responses.add(
            responses.GET,
            f"{self.base_url}/users/{user_id}",
            json={"error": "User not found"},
            status=404
        )
        
        with pytest.raises(Exception):
            self.client.get_user(user_id)

    @responses.activate
    def test_create_user_success(self):
        """Test tworzenia użytkownika - sukces."""
        user_data = {
            "name": "Anna Nowak",
            "email": "anna@example.com"
        }
        expected_response = {
            "id": 2,
            **user_data
        }
        
        responses.add(
            responses.POST,
            f"{self.base_url}/users",
            json=expected_response,
            status=201
        )
        
        result = self.client.create_user(user_data)
        assert result["id"] == 2
        assert result["name"] == user_data["name"]

    @responses.activate
    def test_update_user_success(self):
        """Test aktualizacji użytkownika - sukces."""
        user_id = 1
        update_data = {
            "name": "Jan Kowalski Updated",
            "email": "jan.updated@example.com"
        }
        expected_response = {
            "id": user_id,
            **update_data
        }
        
        responses.add(
            responses.PUT,
            f"{self.base_url}/users/{user_id}",
            json=expected_response,
            status=200
        )
        
        result = self.client.update_user(user_id, update_data)
        assert result["name"] == update_data["name"]

    @responses.activate
    def test_delete_user_success(self):
        """Test usuwania użytkownika - sukces."""
        user_id = 1
        
        responses.add(
            responses.DELETE,
            f"{self.base_url}/users/{user_id}",
            status=200
        )
        
        result = self.client.delete_user(user_id)
        assert result is True

