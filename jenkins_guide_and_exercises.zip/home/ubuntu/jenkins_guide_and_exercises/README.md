# Kompletny Przewodnik: Jenkins, SSH Agent i Testy Pytest

Ten pakiet zawiera kompletny zestaw materiałów instruktażowych dotyczących konfiguracji agenta Jenkins na Ubuntu przez SSH oraz praktyczne ćwiczenia z wykorzystaniem `pytest` w zadaniach Jenkins.

## Zawartość Pakietu

1.  **`jenkins_agent_ssh_setup.md`**
    - Szczegółowa instrukcja krok po kroku, jak skonfigurować połączenie między serwerem Jenkins a agentem na systemie Ubuntu przy użyciu kluczy SSH.
    - Obejmuje przygotowanie obu serwerów, tworzenie dedykowanego użytkownika oraz konfigurację węzła w interfejsie Jenkins.

2.  **`jenkins_jobs_exercises.md`**
    - Przewodnik po tworzeniu zadań (jobów) w Jenkinsie, które automatyzują proces testowania kodu w Pythonie z użyciem `pytest`.
    - Zawiera przykłady konfiguracji dla projektów typu Freestyle oraz nowoczesnych Pipeline (z użyciem `Jenkinsfile`).
    - Demonstruje, jak publikować wyniki testów, raporty HTML oraz raporty pokrycia kodu.

3.  **`jenkins-pytest-exercises/` (katalog)**
    - Zestaw trzech praktycznych projektów w Pythonie, gotowych do wykorzystania w ćwiczeniach z Jenkinsem.
    - Każdy projekt zawiera kod źródłowy, testy `pytest`, plik `requirements.txt` oraz `README.md` z opisem.
    - **Projekty:**
        - `exercise1-basic`: Podstawowe testy jednostkowe.
        - `exercise2-api`: Testowanie klienta API z mockowaniem zapytań HTTP.
        - `exercise3-parametrized`: Zaawansowane testy z wykorzystaniem parametryzacji w `pytest`.

## Jak zacząć?

1.  **Konfiguracja Agenta:** Zacznij od lektury pliku `jenkins_agent_ssh_setup.md` i skonfiguruj swojego agenta zgodnie z instrukcjami.

2.  **Przygotowanie Kodu:** Umieść zawartość katalogu `jenkins-pytest-exercises` w swoim repozytorium Git. Będzie to potrzebne do skonfigurowania zadań w Jenkinsie.

3.  **Tworzenie Jobów:** Postępuj zgodnie z instrukcjami w pliku `jenkins_jobs_exercises.md`, aby stworzyć i skonfigurować swoje pierwsze zautomatyzowane zadania testowe.

Powodzenia!

