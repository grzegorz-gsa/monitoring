# Przewodnik: Konfiguracja Agenta Jenkins na Ubuntu przez SSH

Niniejszy dokument szczegółowo opisuje proces konfiguracji nowego węzła (agenta) dla serwera Jenkins, wykorzystując połączenie SSH. Obie maszyny, zarówno serwer główny (master), jak i agent, działają pod kontrolą systemu operacyjnego Ubuntu.

## Wymagania Wstępne

Przed rozpoczęciem konfiguracji, upewnij się, że spełnione są następujące warunki:

- **Dwa serwery Ubuntu:** Jeden pełniący rolę serwera Jenkins (master), drugi jako agent.
- **Dostęp do sieci:** Serwer master musi mieć możliwość komunikacji z serwerem agenta przez sieć, zazwyczaj na porcie 22 (SSH).
- **Dostęp z uprawnieniami `sudo`:** Na obu maszynach wymagany jest dostęp do użytkownika z możliwością wykonywania poleceń administracyjnych.
- **Zainstalowany Jenkins:** Na serwerze master musi być zainstalowana i działająca usługa Jenkins.
- **Zainstalowana Java:** Java jest wymagana na obu maszynach. Jenkins master już ją posiada. Na agencie należy ją zainstalować. Można to zrobić poleceniem: `sudo apt update && sudo apt install -y openjdk-17-jre`.

## Krok 1: Przygotowanie Serwera Agenta

Na maszynie, która ma pełnić rolę agenta, należy wykonać poniższe czynności w celu stworzenia dedykowanego użytkownika dla Jenkinsa i przygotowania środowiska SSH.

1.  **Utwórz użytkownika `jenkins`:**
    Zaleca się, aby procesy Jenkinsa działały na dedykowanym koncie użytkownika. Utwórz użytkownika o nazwie `jenkins`.
    ```bash
    sudo useradd -m -s /bin/bash jenkins
    ```

2.  **Skonfiguruj uwierzytelnianie SSH:**
    Przełącz się na nowo utworzonego użytkownika `jenkins`, aby wygenerować dla niego parę kluczy SSH. Ten klucz nie będzie używany do połączenia, ale stworzy katalog `.ssh` z odpowiednimi uprawnieniami.
    ```bash
    sudo su - jenkins
    ssh-keygen -t rsa -f ~/.ssh/id_rsa -N ""
    ```
    Następnie utwórz plik `authorized_keys`, do którego wkleimy klucz publiczny serwera master.
    ```bash
    touch ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
    exit
    ```

## Krok 2: Przygotowanie Serwera Master

Na serwerze master Jenkinsa również potrzebujemy pary kluczy SSH dla użytkownika, w kontekście którego działa usługa Jenkins (domyślnie jest to również użytkownik `jenkins`).

1.  **Sprawdź i wygeneruj klucze SSH dla użytkownika `jenkins`:**
    Przełącz się na użytkownika `jenkins` i sprawdź, czy klucze już istnieją. Jeśli nie, wygeneruj je.
    ```bash
    sudo su - jenkins
    ls -l ~/.ssh/id_rsa.pub
    ```
    Jeśli polecenie zwróci błąd 

o nieznalezieniu pliku, wygeneruj nową parę kluczy:
    ```bash
    ssh-keygen -t rsa -f ~/.ssh/id_rsa -N ""
    ```

2.  **Skopiuj klucz publiczny na serwer agenta:**
    Teraz skopiuj zawartość klucza publicznego (`~/.ssh/id_rsa.pub`) z serwera master do pliku `~/.ssh/authorized_keys` na serwerze agenta, w katalogu domowym użytkownika `jenkins`.
    ```bash
    cat ~/.ssh/id_rsa.pub
    ```
    Skopiuj wyświetlony klucz, a następnie na serwerze agenta wklej go do pliku:
    ```bash
    sudo su - jenkins
    echo "<wklej_tutaj_klucz_publiczny>" >> ~/.ssh/authorized_keys
    exit
    ```

## Krok 3: Konfiguracja Nowego Węzła (Agenta) w Jenkins

Teraz, gdy serwery są przygotowane do komunikacji, możemy dodać nowy węzeł w interfejsie webowym Jenkinsa.

1.  **Przejdź do zarządzania węzłami:**
    W panelu Jenkinsa przejdź do `Dashboard` > `Manage Jenkins` > `Nodes`.

2.  **Dodaj nowy węzeł:**
    Kliknij `New Node` w menu po lewej stronie.
    - **Node Name:** Wprowadź nazwę dla swojego agenta, np. `ubuntu-agent-01`.
    - Wybierz `Permanent Agent`.
    - Kliknij `Create`.

3.  **Skonfiguruj szczegóły węzła:**
    Na ekranie konfiguracji agenta wypełnij następujące pola:

    - **Description:** (Opcjonalnie) Krótki opis agenta.
    - **# of executors:** Liczba jednoczesnych zadań, które agent może wykonywać. Zazwyczaj ustawia się ją na liczbę rdzeni procesora. Zacznij od `1` lub `2`.
    - **Remote root directory:** Ścieżka do katalogu roboczego Jenkinsa na agencie. Użyj katalogu domowego użytkownika `jenkins`, np. `/home/jenkins`.
    - **Labels:** Etykiety służą do grupowania agentów i przypisywania im konkretnych zadań. Możesz dodać etykietę, np. `ubuntu` lub `python-builder`.
    - **Usage:** Wybierz `Use this node as much as possible`.
    - **Launch method:** Wybierz `Launch agents via SSH`.
        - **Host:** Adres IP lub nazwa domenowa serwera agenta.
        - **Credentials:** Kliknij `Add` > `Jenkins`, aby dodać nowe poświadczenia.
            - **Kind:** `SSH Username with private key`.
            - **ID:** (Opcjonalnie) Unikalny identyfikator dla poświadczeń.
            - **Description:** (Opcjonalnie) Opis poświadczeń.
            - **Username:** `jenkins`.
            - **Private Key:** Zaznacz `Enter directly` i wklej zawartość **klucza prywatnego** z serwera master (znajdującego się w `~/.ssh/id_rsa` w katalogu domowym użytkownika `jenkins`). Skopiuj go poleceniem `cat ~/.ssh/id_rsa` na serwerze master, będąc zalogowanym jako użytkownik `jenkins`.
            - Kliknij `Add`.
        - Po dodaniu poświadczeń, wybierz je z listy rozwijanej.
        - **Host Key Verification Strategy:** Wybierz `Non-verifying Verification Strategy` dla uproszczenia pierwszej konfiguracji. W środowiskach produkcyjnych zaleca się użycie `Known hosts file Verification Strategy` lub `Manually provided key Verification Strategy`.

4.  **Zapisz i uruchom agenta:**
    Kliknij `Save`. Agent pojawi się na liście węzłów. Początkowo będzie oznaczony jako odłączony. Kliknij na jego nazwę, a następnie `Launch agent`, aby Jenkins spróbował nawiązać połączenie.

    Jeśli wszystko zostało poprawnie skonfigurowane, po chwili agent zostanie oznaczony jako połączony i gotowy do pracy.

## Rozwiązywanie Problemów

- **Błędy uwierzytelniania:** Najczęstszym problemem są błędy związane z kluczami SSH. Upewnij się, że:
    - Klucz publiczny z mastera jest poprawnie wklejony w `authorized_keys` na agencie.
    - Klucz prywatny z mastera jest poprawnie wklejony w konfiguracji poświadczeń w Jenkins.
    - Uprawnienia do katalogu `.ssh` i pliku `authorized_keys` na agencie są prawidłowe (`700` dla katalogu, `600` dla pliku).
- **Błędy połączenia:** Sprawdź, czy serwer master może połączyć się z agentem przez SSH z wiersza poleceń, używając użytkownika `jenkins`:
  ```bash
  sudo su - jenkins
  ssh jenkins@<adres_ip_agenta>
  ```
- **Brak Javy na agencie:** Upewnij się, że na serwerze agenta jest zainstalowana Java. Błędy związane z brakiem Javy będą widoczne w logach uruchamiania agenta w interfejsie Jenkinsa.

